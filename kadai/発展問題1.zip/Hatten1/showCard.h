#ifndef SHOWCARD_H
#define SHOWCARD_H

#include <stdio.h>
int showInitCard(int [], int);
int showCard(int, int);

#endif