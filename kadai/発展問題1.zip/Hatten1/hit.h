#ifndef HIT_H
#define HIT_H

int hit();

#endif