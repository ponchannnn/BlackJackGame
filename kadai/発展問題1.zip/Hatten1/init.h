#ifndef INIT_H
#define INIT_H

int init (int [], int);

#endif