#ifndef DEALERTURN_H
#define DEALERTURN_H

int isBurst(int);
int playerTurn();
int dealerTurn();

#endif