#ifndef IFHIT_H
#define IFHIT_H

int ifHit();

#endif