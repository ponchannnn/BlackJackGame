#ifndef ADJUSTCARD_H
#define ADJUSTCARD_H

#include <stdio.h>
int adjustCard(int, int);
int adjustInitCard(int, int);
void showScore(int, int);

#endif