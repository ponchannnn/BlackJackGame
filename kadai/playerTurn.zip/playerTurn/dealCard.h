#ifndef DEALCARD_H
#define DEALCARD_H

int dealCard();

#endif