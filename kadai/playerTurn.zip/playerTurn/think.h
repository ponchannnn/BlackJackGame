#ifndef THINK_H
#define THINK_H

void think(int n);

#endif